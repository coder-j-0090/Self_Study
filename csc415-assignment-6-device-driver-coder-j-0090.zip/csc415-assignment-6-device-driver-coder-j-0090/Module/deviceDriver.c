/**************************************************************
* Class::  CSC-415-01 Fall 2024
* Name::Junyoung Kim
* Student ID::920303420
* GitHub-Name::coder-j-0090
* Project:: Assignment 6 – Device Driver
*
* File:: deviceDriver.c
*
* Description::It runs a Linux Kernel Module that work as 
* 	      device driver. It allows user application to 
*	      enable read, write, encryption, and decryption.
*	      It uses 'ioctl' to handle encryption and
*	      decryption.
*
**************************************************************/

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/vmalloc.h>
#include <linux/sched.h>
#include <linux/uaccess.h>

#define CENTER 415
#define SIDE 0
#define DEVICE_NAME "deviceDriver"
#define ENCRYPTION_ON 'e'
#define DECRYPTION_ON 'd'

#define BUFFER_SIZE 512
#define RANGE_MAX 255 // this is the ASCII range
#define SHIFT 5

MODULE_AUTHOR("Junyoung Kim")
MODULE_DESCRIPTION("Device Driver")
MODULE_LICENSE("GPL")

static ssize_t dr_read(struct file *fs, char __user *buf, loff_t *off, size_t hsize);
static ssize_t dr_write(struct file *fs, const char __user *buf, loff_t *off, size_t hsize);
static int dr_open(struct inode *inode, struct file *fs);
static int dr_close(struct file *fs,  struct inode *inode);
static long dr_ioctl(struct file *fs, unsigned long data, unsigned int com);

static int encrypt(char *);
static int decrypt(char *);

int center, side;
struct cdev dr_cdev;

//Struct to check if the text is encrypted or not
typedef struct dr_ds
{
	char *text;	//text for encryption
	int isEncrypted;	//1 if encrypted, 0 if not
}dr_ds;

//file operation 
struct file_operations file_ops= {
	.open = dr_open,
	.release = dr_close,
	.read = dr_read,
	.write = dr_write,
	.unlocked_ioctl = dr_ioctl,
	.owner = THIS_MODULE
};

//Store text in driver 
static ssize_t dr_read(struct file *fs, char __user *buf, loff_t *off, size_t hsize)
{
	struct dr_ds *ds;
	ds = (struct dr_ds *)fs->private_data;

	int copy_check = copy_to_user(*off + buf, ds->text, hsize);

	if(copy_check!=0)
	{
		printk(KERN_ERR "Fail! %d was not copied", copy_check);
		return -1;
	}
	return 0;
}

static ssize_t dr_write(struct file *fs, const char __user *buf, loff_t *off, size_t hsize)
{
	struct dr_ds *ds;
	ds = (struct dr_ds *)fs->private_data;

	int write_copy_check = copy_from_user(ds->text, *off + buf, hsize);

	if(write_copy_check != 0)
	{
		printk(KERN_ERR "Fail! %d was not copied", write_copy_check);
                return -1;
	}
	return 0;
}

static int dr_open(struct file *fs, struct inode *inode)
{
	struct dr_ds *ds;
	ds = vmalloc(sizeof(struct dr_ds));

	if(!ds)
	{
		printk(KERN_ERR "vmalloc fail! Can't open!");
		return -1;
	}
	fs->private_data = ds;
	ds->text = vmalloc(BUFFER_SIZE);
	ds->isEncrypted=0;
	return 0;
}

static int dr_close(struct file *fs,  struct inode *inode)
{
	struct dr_ds *ds;
	ds = (struct dr_ds *)fs->private_data;
	vfree(ds->text);
	vfree(ds);
	return 0;
}

static long dr_ioctl(struct file *fs, unsigned long data, unsigned int com)
{
	struct dr_ds *ds;
	ds = (struct dr_ds *)fs->private_data;

	switch(com)
	{
		case ENCRYPTION_ON:
			encrypt(ds->text);
			ds->isEncrypted = 1;
        		break;

		case DECRYPTION_ON:
			decrypt(ds->text);
        		ds->isEncrypted = 0;
        		break;
	}

	return 0;
}

static int encrypt(char *text)
{
	printk(KERN_INFO "Encrypting: %s\n", text);
	
	for(size_t i=0; i<strlen(text); i++)
	{
		text[i] = (text[i] + SHIFT) % RANGE_MAX;
	}

	printk(KERN_INFO "Encrypted as : %s\n", text);
	return 0;
}

static int decrypt(char *text)
{
	printk(KERN_INFO "Decrypting: %s\n", text);

	for(size_t i=0;i<strlen(text); i++)
	{
		text[i] = (text[i] - SHIFT) % RANGE_MAX;
	}

	printk(KERN_INFO "Decrypted as : %s\n", text);
	return 0;
}

//Register Devide Node
int init(void)
{
	int res, reg;
	dev_t dev;

	dev = MKDEV(CENTER, SIDE);
	reg = register_chrdev_region(dev, 1, DEVICE_NAME);
	printk(KERN_INFO "Register suceeded 1: %d\n", reg);
	cdev_init(&dr_cdev, &file_ops);
	dr_cdev.owner = THIS_MODULE;

	res = cdev_add(&dr_cdev, dev, 1);
	printk(KERN_INFO "Register suceeded 2: %d\n", res);
        printk(KERN_INFO "Device Driver is loaded.\n"); 

	if (0>res)
    	{
        	printk(KERN_ERR "Register failed: %d\n", res);
    	}
    	return res;
}

void remove_driver(void)
{
	dev_t rmdev;
	rmdev = MKDEV(CENTER, SIDE);

	unregister_chrdev_region(rmdev, 1);
        cdev_del(&dr_cdev);
        printk(KERN_INFO "Device Driver is removed.\n");
}
