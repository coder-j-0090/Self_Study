/**************************************************************
* Class::  CSC-415-01 Fall 2024
* Name:: Junyoung Kim
* Student ID:: 920303420
* GitHub-Name:: coder-j-0090
* Project:: Assignment 6 - Device Driver
*
* File:: Kim_Junyoung_HW6_main.c
*
* Description:: Device Driver Test
**************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#define BUFFER_SIZE 512
#define DEV_LOCATION "/dev/deviceDriver"
#define ENCRYPTION_ON 'e'
#define DECRYPTION_ON 'd'

int main(int argc, char const *argv[])
{
	if (argc < 3)
        {
		printf("Not enough arguments\n");
                return -1;
        }

	const char mode = argv[1][0];
        const char *text = argv[2];

	if (mode != DECRYPTION_ON && mode != ENCRYPTION_ON)
    	{
        	printf("Invalid mode: must be 'e' or 'd'");
        	return -1;
    	}

	int n = open(DEV_LOCATION, O_RDWR);
	if(0>n)
	{
		printf("Open Error!\n");
        	return -1;
	}

	write(n, text, strlen(text));
	ioctl(n, mode);

	char *res = malloc(BUFFER_SIZE);
	read(n, res, strlen(text));
	printf("%s\n", res);

	close(n);
	return 0;
}
